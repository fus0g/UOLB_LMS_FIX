/**
 * UoL Bengaluru Canvas SAML Auto-Login
 * Automatically detects Canvas login pages and redirects to University SAML 12 SSO.
 */

(function () {
  'use strict';

  const DEFAULT_SAML_URL = 'https://www.lms.bengaluru.liverpool.ac.uk/login/saml/12';
  const LOOP_STORAGE_KEY_TS = 'uol_saml_last_redirect_ts';
  const LOOP_STORAGE_KEY_COUNT = 'uol_saml_redirect_count';
  const MAX_RAPID_REDIRECTS = 2;
  const RAPID_WINDOW_MS = 8000; // 8 seconds

  // Fast check: read cached local setting or fallback to true
  let isAutoRedirectEnabled = true;
  let targetSamlBaseUrl = DEFAULT_SAML_URL;
  let preserveReturnTo = true;

  try {
    const cachedEnabled = localStorage.getItem('uol_saml_auto_redirect');
    if (cachedEnabled !== null) {
      isAutoRedirectEnabled = cachedEnabled === 'true';
    }
    const cachedUrl = localStorage.getItem('uol_saml_base_url');
    if (cachedUrl) {
      targetSamlBaseUrl = cachedUrl;
    }
  } catch (e) {
    // LocalStorage might be restricted in some sandboxes
  }

  // Load extension settings from storage API
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.sync) {
    chrome.storage.sync.get(
      {
        autoRedirect: true,
        samlUrl: DEFAULT_SAML_URL,
        preserveReturnTo: true
      },
      (items) => {
        isAutoRedirectEnabled = items.autoRedirect !== false;
        targetSamlBaseUrl = items.samlUrl || DEFAULT_SAML_URL;
        preserveReturnTo = items.preserveReturnTo !== false;
        try {
          localStorage.setItem('uol_saml_auto_redirect', String(isAutoRedirectEnabled));
          localStorage.setItem('uol_saml_base_url', targetSamlBaseUrl);
        } catch (e) {}

        // If page has rendered login form and auto-redirect is disabled, make sure button is injected
        if (!isAutoRedirectEnabled && isLoginPage()) {
          injectSamlUI(buildTargetUrl());
        }
      }
    );
  }

  // Check if current URL is an exception (do NOT redirect if already authenticating)
  function isSamlOrOAuthRoute() {
    const path = window.location.pathname.toLowerCase();
    return (
      path.startsWith('/login/saml') ||
      path.startsWith('/saml_consume') ||
      path.startsWith('/login/oauth2') ||
      window.location.search.includes('no_saml_redirect=1') ||
      window.location.search.includes('manual_login=1')
    );
  }

  // Build the complete destination URL with return_to parameter if applicable
  function buildTargetUrl() {
    try {
      const currentUrl = new URL(window.location.href);
      const target = new URL(targetSamlBaseUrl, window.location.origin);

      if (preserveReturnTo) {
        const existingReturnTo = currentUrl.searchParams.get('return_to');
        if (existingReturnTo) {
          target.searchParams.set('return_to', existingReturnTo);
        } else if (
          currentUrl.pathname !== '/' &&
          currentUrl.pathname !== '/login' &&
          currentUrl.pathname !== '/login/canvas' &&
          !currentUrl.pathname.startsWith('/login/')
        ) {
          target.searchParams.set('return_to', currentUrl.href);
        }
      }

      return target.href;
    } catch (e) {
      return targetSamlBaseUrl;
    }
  }

  // Detect whether a rapid redirect loop is occurring
  function isLoopDetected() {
    try {
      const now = Date.now();
      const lastTs = parseInt(sessionStorage.getItem(LOOP_STORAGE_KEY_TS) || '0', 10);
      const count = parseInt(sessionStorage.getItem(LOOP_STORAGE_KEY_COUNT) || '0', 10);

      if (now - lastTs < RAPID_WINDOW_MS && count >= MAX_RAPID_REDIRECTS) {
        return true;
      }
    } catch (e) {}
    return false;
  }

  // Record an ongoing redirect attempt
  function recordRedirectAttempt() {
    try {
      const now = Date.now();
      const lastTs = parseInt(sessionStorage.getItem(LOOP_STORAGE_KEY_TS) || '0', 10);
      let count = parseInt(sessionStorage.getItem(LOOP_STORAGE_KEY_COUNT) || '0', 10);

      if (now - lastTs < RAPID_WINDOW_MS) {
        count += 1;
      } else {
        count = 1;
      }

      sessionStorage.setItem(LOOP_STORAGE_KEY_TS, String(now));
      sessionStorage.setItem(LOOP_STORAGE_KEY_COUNT, String(count));
    } catch (e) {}
  }

  // Clear loop counters when user is authenticated
  function clearLoopCounters() {
    try {
      sessionStorage.removeItem(LOOP_STORAGE_KEY_TS);
      sessionStorage.removeItem(LOOP_STORAGE_KEY_COUNT);
    } catch (e) {}
  }

  // Check if current DOM state indicates a login page
  function isLoginPage() {
    if (
      window.location.pathname === '/login/canvas' ||
      window.location.pathname === '/login' ||
      window.location.pathname === '/login/'
    ) {
      return true;
    }

    if (
      document.body &&
      (document.body.classList.contains('ic-Login-Body') ||
        document.getElementById('login_form') ||
        document.querySelector('form[action*="/login/canvas"]'))
    ) {
      return true;
    }

    if (document.title && document.title.toLowerCase().includes('log in to canvas')) {
      return true;
    }

    return false;
  }

  // Perform redirect with overlay notification
  function performRedirect(targetUrl) {
    if (isLoopDetected()) {
      console.warn('[LMS SAML Auto-Login] Redirect loop detected. Pausing auto-redirect.');
      showLoopNotice(targetUrl);
      injectSamlUI(targetUrl);
      return;
    }

    recordRedirectAttempt();

    // Show temporary toast if body exists
    try {
      if (document.body) {
        const toast = document.createElement('div');
        toast.className = 'uol-saml-redirect-overlay';
        toast.innerHTML = `
          <div class="uol-saml-spinner"></div>
          <span>Connecting to University SAML SSO...</span>
        `;
        document.body.appendChild(toast);
      }
    } catch (e) {}

    // Instant replace avoids adding the bad login page to history
    window.location.replace(targetUrl);
  }

  // Show banner when a redirect loop is prevented
  function showLoopNotice(targetUrl) {
    if (document.getElementById('uol-saml-loop-banner')) return;

    const loginBody = document.querySelector('.ic-Login__body') || document.getElementById('login_form');
    if (!loginBody) return;

    const banner = document.createElement('div');
    banner.id = 'uol-saml-loop-banner';
    banner.className = 'uol-saml-banner';
    banner.innerHTML = `
      <strong>Auto-Redirect Paused</strong>
      A rapid redirect was detected. To sign in with your University of Liverpool Bengaluru credentials, 
      <a href="${targetUrl}" class="uol-saml-link">click here to use SAML 12 Login</a>, 
      or sign in using the form below.
    `;

    loginBody.parentNode.insertBefore(banner, loginBody);
  }

  // Inject a high-visibility SAML Login button above standard Canvas login inputs
  function injectSamlUI(targetUrl) {
    if (document.getElementById('uol-saml-custom-btn')) return;

    const loginForm = document.getElementById('login_form') || document.querySelector('form[action*="/login/canvas"]');
    if (!loginForm) return;

    const container = document.createElement('div');
    container.id = 'uol-saml-custom-btn';
    container.className = 'uol-saml-btn-container';

    container.innerHTML = `
      <a href="${targetUrl}" class="uol-saml-btn" role="button">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/>
          <polyline points="10 17 15 12 10 7"/>
          <line x1="15" y1="12" x2="3" y2="12"/>
        </svg>
        <span>Log in with University SAML (SSO)</span>
      </a>
      <div class="uol-saml-divider">
        <span>or standard canvas login</span>
      </div>
    `;

    // Insert right before the first form control (Email input)
    const firstControl = loginForm.querySelector('.ic-Form-control');
    if (firstControl) {
      loginForm.insertBefore(container, firstControl);
    } else {
      loginForm.prepend(container);
    }
  }

  // If already on SAML or OAuth route, skip redirect
  if (isSamlOrOAuthRoute()) {
    return;
  }

  const currentPath = window.location.pathname.toLowerCase();
  const targetUrl = buildTargetUrl();

  // Fast-path: Explicit login paths (/login/canvas, /login)
  if (currentPath === '/login/canvas' || currentPath === '/login' || currentPath === '/login/') {
    if (isAutoRedirectEnabled) {
      performRedirect(targetUrl);
      return;
    } else {
      // If auto-redirect is off, wait for DOM to inject button
      document.addEventListener('DOMContentLoaded', () => injectSamlUI(targetUrl));
      return;
    }
  }

  // Observation path: For root '/' or deep links where Canvas may render the login page in-place
  let handled = false;

  function evaluatePage() {
    if (handled) return;

    if (isLoginPage()) {
      handled = true;
      if (isAutoRedirectEnabled) {
        performRedirect(targetUrl);
      } else {
        injectSamlUI(targetUrl);
      }
    } else if (
      document.getElementById('wrapper') ||
      document.getElementById('dashboard') ||
      document.getElementById('header') ||
      (document.body && !document.body.classList.contains('ic-Login-Body') && document.readyState === 'complete')
    ) {
      // User is logged in to Canvas dashboard
      clearLoopCounters();
      handled = true;
      if (observer) observer.disconnect();
    }
  }

  // Use MutationObserver for near-instant detection as DOM elements stream in
  const observer = new MutationObserver(() => {
    evaluatePage();
  });

  observer.observe(document.documentElement || document, {
    childList: true,
    subtree: true
  });

  // Fallbacks for DOM lifecycle stages
  document.addEventListener('DOMContentLoaded', evaluatePage);
  window.addEventListener('load', evaluatePage);
})();
